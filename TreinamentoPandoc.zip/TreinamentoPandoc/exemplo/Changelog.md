# Changelog

| Versão | Data     | Responsável    | Tipo de Mudanças |
| ------ |----------|----------------|------------------| 
| V1.0.0 | ???/2024 | John Doe       | Versão inicial   |

## Conteúdo de cada versão

**V1.0.0** - Apenas um treinamento
  