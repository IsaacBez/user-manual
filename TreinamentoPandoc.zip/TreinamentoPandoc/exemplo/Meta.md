\newcommand{\tipbox}[3]{$
\definecolor{ErrorHeaderBG}{RGB}{17, 133, 3}
\definecolor{ErrorHeaderFG}{RGB}{255, 255, 255}
\definecolor{ErrorBodyBG}{RGB}{231, 242, 229}
\definecolor{ErrorBodyFG}{RGB}{17, 133, 3}
\setlength{\arrayrulewidth}{0mm}
\begin{tabular}{ p{#1\linewidth} }
\hline
\rowcolor{ErrorHeaderBG} \multicolumn{1}{|c|}{\color{ErrorHeaderFG}\textbf{#2}} \\
\hline
\rowcolor{ErrorBodyBG} \color{ErrorBodyFG}#3 \\
\hline
\end{tabular}
$}

\newcommand{\infobox}[3]{$
\definecolor{ErrorHeaderBG}{RGB}{0, 112, 188}
\definecolor{ErrorHeaderFG}{RGB}{255, 255, 255}
\definecolor{ErrorBodyBG}{RGB}{230, 241, 248}
\definecolor{ErrorBodyFG}{RGB}{0, 112, 188}
\setlength{\arrayrulewidth}{0mm}
\begin{tabular}{ p{#1\linewidth} }
\hline
\rowcolor{ErrorHeaderBG} \multicolumn{1}{|c|}{\color{ErrorHeaderFG}\textbf{#2}} \\
\hline
\rowcolor{ErrorBodyBG} \color{ErrorBodyFG}#3 \\
\hline
\end{tabular}
$}

\newcommand{\warningbox}[3]{$
\definecolor{ErrorHeaderBG}{RGB}{246, 134, 33}
\definecolor{ErrorHeaderFG}{RGB}{255, 255, 255}
\definecolor{ErrorBodyBG}{RGB}{252, 240, 214}
\definecolor{ErrorBodyFG}{RGB}{246, 134, 33}
\setlength{\arrayrulewidth}{0mm}
\begin{tabular}{ p{#1\linewidth} }
\hline
\rowcolor{ErrorHeaderBG} \multicolumn{1}{|c|}{\color{ErrorHeaderFG}\textbf{#2}} \\
\hline
\rowcolor{ErrorBodyBG} \color{ErrorBodyFG}#3 \\
\hline
\end{tabular}
$}

\newcommand{\errorbox}[3]{$
\definecolor{ErrorHeaderBG}{RGB}{204, 0, 0}
\definecolor{ErrorHeaderFG}{RGB}{255, 255, 255}
\definecolor{ErrorBodyBG}{RGB}{255, 227, 227}
\definecolor{ErrorBodyFG}{RGB}{204, 0, 0}
\setlength{\arrayrulewidth}{0mm}
\begin{tabular}{ p{#1\linewidth} }
\hline
\rowcolor{ErrorHeaderBG} \multicolumn{1}{|c|}{\color{ErrorHeaderFG}\textbf{#2}} \\
\hline
\rowcolor{ErrorBodyBG} \color{ErrorBodyFG}#3 \\
\hline
\end{tabular}
$}

\newcommand{\custombox}[7]{$
\definecolor{ErrorHeaderBG}{RGB}{204, 0, 0}
\definecolor{ErrorHeaderFG}{RGB}{255, 255, 255}
\definecolor{ErrorBodyBG}{RGB}{255, 227, 227}
\definecolor{ErrorBodyFG}{RGB}{204, 0, 0}
\setlength{\arrayrulewidth}{0mm}
\begin{tabular}{ p{#5\linewidth} }
\hline
\rowcolor{#1} \multicolumn{1}{|c|}{\color{#2}\textbf{#6}} \\
\hline
\rowcolor{#3} \color{#4}#7 \\
\hline
\end{tabular}
$}